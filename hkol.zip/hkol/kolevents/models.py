from __future__ import unicode_literals

from django.db import models




class slider(models.Model):
    sliderimage = models.FileField(upload_to="documents/media")
    slidername = models.CharField(max_length=100)
    slidercontent = models.TextField()

    class Meta:
	verbose_name_plural = "Banner Slider"


class comp(models.Model):
    companylogo = models.FileField(upload_to="documents/media")
    companyname = models.CharField(max_length=200)

    class Meta:
	verbose_name_plural = "Company Details"



class logo(models.Model):
    logoimage = models.FileField(upload_to="documents/media")
    logourl = models.CharField(max_length=500)

    class Meta:
	verbose_name_plural = "Client Logo"


class services(models.Model):
    servicename = models.CharField(max_length=100)
    serviceimgae = models.FileField(upload_to="documents/media")
    servicecontent = models.TextField()

    class Meta:
	verbose_name_plural = "Service"



class promotion(models.Model):
    promotionname = models.CharField(max_length=100)
    promotionimage = models.FileField(upload_to="documents/media")

    class Meta:
	verbose_name_plural = "Promotion"



class albums(models.Model):
    albumsname = models.CharField(max_length=100)
    albumsimage = models.FileField(upload_to="documents/media")

    class Meta:
	verbose_name_plural = "Albums"



class tour(models.Model):
    tourname = models.CharField(max_length=100)
    tourcontent = models.TextField()
    tourdate = models.DateField()

    class Meta:
	verbose_name_plural = "Upcoming Events"


class gallery(models.Model):
    galleryname = models.CharField(max_length=100)
    galleryimage = models.FileField(upload_to="documents/media")

    class Meta:
	verbose_name_plural = "Gallery"



class video(models.Model):
    videoname = models.CharField(max_length=200)
    videourl = models.CharField(max_length=500)

    class Meta:
	verbose_name_plural = "Videos"



class mail(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    subject = models.CharField(max_length=250)
    content = models.TextField()
