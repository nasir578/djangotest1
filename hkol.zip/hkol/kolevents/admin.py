from django.contrib import admin
from kolevents.views import *
from kolevents.models import *



class sliderAdmin(admin.ModelAdmin):
    list_display = ['slidername', 'id']

class compAdmin(admin.ModelAdmin):
    list_display = ['companyname', 'companylogo']


class logoAdmin(admin.ModelAdmin):
    list_display = ['id']

class servicesAdmin(admin.ModelAdmin):
    list_display = ['servicename']

class newsAdmin(admin.ModelAdmin):
    list_display = ['newsnme']


class albumsAdmin(admin.ModelAdmin):
    list_display = ['albumsname', 'id']

class tourAdmin(admin.ModelAdmin):
    list_display = ['tourname']


class galleryAdmin(admin.ModelAdmin):
    list_display = ['galleryname']


class videoAdmin(admin.ModelAdmin):
    list_display = ['videoname']

class promotionAdmin(admin.ModelAdmin):
    list_display = ['promotionname']

class compAdmin(admin.ModelAdmin):
    list_display = ['companyname']








admin.site.register(video, videoAdmin)
admin.site.register(slider, sliderAdmin)
admin.site.register(comp, compAdmin)
admin.site.register(logo, logoAdmin)
admin.site.register(services, servicesAdmin)
admin.site.register(albums, albumsAdmin)
admin.site.register(tour, tourAdmin)
admin.site.register(gallery, galleryAdmin)
admin.site.register(promotion, promotionAdmin)
