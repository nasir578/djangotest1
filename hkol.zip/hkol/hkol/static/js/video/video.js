$(function(){
  $.okvideo({
      source: 'q6h0_9Zv7aM',
      volume: 0,
	controls: false,
	captions: false,
	autoplay: true,
	disablekeyControl: true
  });
});

